@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Lista de cuartos</h1>
@stop

@section('content')
    <p>En este panel se mostraran todos los cuartos ordenados por fecha de fin de renta.</p>

@stop

@section('css')
    <link rel="stylesheet" href="public/vendor/adminlte/dist/css/admin_custom.css">
@stop